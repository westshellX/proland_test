"Real-time Realistic Ocean Lighting using 
Seamless Transitions from Geometry to BRDF"
Eric Bruneton, Fabrice Neyret, Nicolas Holzschuch
Eurographics 2010

User Interface
- mouse drag = move the Sun
- page up / page down : increase / decrease distance to ground
- + / - : increase / decrease camera tilt angle
- 1 ... 9 : save scene
- F1 ... F9 : load scene
- ESC : exit
